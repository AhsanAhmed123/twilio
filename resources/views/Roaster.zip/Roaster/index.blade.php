@extends('layouts.layout')
@section('content')
</br>
</br>
</br>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.css">
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

<div class="page-content-wrapper container">

    <div class="container mt-5">
        <div class="d-flex justify-content-between">
            <button class="btn btn-primary" onclick="showRosterForm()">Roster View</button>
            <button class="btn btn-secondary" onclick="showCalendar()">Calendar View</button>
        </div>
        
        <!-- Calendar -->
        <div id="calendar" class="mt-4"></div>

        <!-- Roster Form -->
        <div id="rosterForm" class="mt-4" style="display: none;">
            <h3>Manage Roster</h3>
           <select class="form-control mb-2" id="username">
            <option>Select Employee</option>
            @foreach ($employees as $employee)
            <option value="{{ $employee->id }}">{{ $employee->name }}</option>
            @endforeach
           </select>
            <input type="datetime-local" id="start_time" class="form-control mb-2">
            <input type="datetime-local" id="end_time" class="form-control mb-2">
            
            <label>Select Days:</label>
            <div id="days">
                <button type="button" class="btn btn-outline-primary" onclick="toggleDay(this)">Mon</button>
                <button type="button" class="btn btn-outline-primary" onclick="toggleDay(this)">Tue</button>
                <button type="button" class="btn btn-outline-primary" onclick="toggleDay(this)">Wed</button>
                <button type="button" class="btn btn-outline-primary" onclick="toggleDay(this)">Thu</button>
                <button type="button" class="btn btn-outline-primary" onclick="toggleDay(this)">Fri</button>
                <button type="button" class="btn btn-outline-primary" onclick="toggleDay(this)">Sat</button>
                <button type="button" class="btn btn-outline-primary" onclick="toggleDay(this)">Sun</button>
            </div>
            <button class="btn btn-success mt-2" onclick="saveRoster()">Save</button>
        </div>
    </div>
</div>

    <script>
        let selectedDays = [];

        function toggleDay(button) {
            let day = button.innerText;
            if (selectedDays.includes(day)) {
                selectedDays = selectedDays.filter(d => d !== day);
                button.classList.remove('btn-primary');
                button.classList.add('btn-outline-primary');
            } else {
                selectedDays.push(day);
                button.classList.add('btn-primary');
                button.classList.remove('btn-outline-primary');
            }
        }

        function showRosterForm() {
            document.getElementById('calendar').style.display = 'none';
            document.getElementById('rosterForm').style.display = 'block';
        }

        function showCalendar() {
            document.getElementById('calendar').style.display = 'block';
            document.getElementById('rosterForm').style.display = 'none';
        }

        function saveRoster() {
            $.ajax({
                url: '/roster-save',
                method: 'POST',
                data: {
                    _token: "{{ csrf_token() }}",
                    username: $('#username').val(),
                    start_time: $('#start_time').val(),
                    end_time: $('#end_time').val(),
                    days: selectedDays
                },
                success: function () {
                    alert('Roster saved!');
                }
            });
        }

        document.addEventListener('DOMContentLoaded', function () {
            var calendarEl = document.getElementById('calendar');
            var calendar = new FullCalendar.Calendar(calendarEl, {
                  initialView: 'dayGridMonth',
                events: '/roster-details',
                selectable: true,
                select: function (info) {
                    var title = prompt("Enter Event Title:");
                    if (title) {
                        $.ajax({
                            url: '/roster-details',
                            method: 'POST',
                            data: {
                                _token: "{{ csrf_token() }}",
                                title: title,
                                start: info.startStr,
                                end: info.endStr
                            },
                            success: function () {
                                calendar.render();
                            }
                        });
                    }
                }
            });
            calendar.render();
        });

        document.addEventListener('DOMContentLoaded', function () {
            var calendarEl = document.getElementById('calendar');
            var calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth',
                events: '/roster-details', 
            });
            calendar.render();
        });


    </script>
@endsection